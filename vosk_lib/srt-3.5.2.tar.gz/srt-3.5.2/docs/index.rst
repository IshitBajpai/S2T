`srt`: Parse SubRip files
=========================

srt_ is a tiny Python library for parsing, modifying, and composing SRT files.

.. _srt: https://github.com/cdown/srt

Documentation
=============

.. toctree::
   :maxdepth: 2

   quickstart
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
