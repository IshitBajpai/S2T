API documentation
=================

.. automodule:: srt
   :members:
